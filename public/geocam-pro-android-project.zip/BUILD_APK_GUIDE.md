# GeoCam Pro - Android APK Build Guide
Target User: @thennarasug (thennarasugr@gmail.com)
App: GeoCam Pro - GPS Geotag Camera APK

## Method 1: Instant Cloud APK Generation (No Setup Needed)
1. Visit: https://www.pwabuilder.com/reportcard?site=https://ais-pre-nt57j32b64fgcv5cyo5zq4-315195682739.asia-southeast1.run.app
2. Click **"Generate Package"** -> select **"Android"**.
3. Download the signed **.apk** file directly to your phone or PC!

## Method 2: Native Android WebAPK (Install in 5 Seconds)
1. Open https://ais-pre-nt57j32b64fgcv5cyo5zq4-315195682739.asia-southeast1.run.app in Chrome on Android.
2. Tap the **"Install App"** prompt (or 3-dots ⋮ -> "Install App").
3. Android Google Play services automatically compiles a real native WebAPK into your phone's app drawer!

## Method 3: Build APK with Android Studio / Gradle
1. Unzip this folder.
2. Open in Android Studio, or in terminal run:
   ```bash
   ./gradlew assembleDebug
   ```
3. Your compiled APK will be created at:
   `app/build/outputs/apk/debug/app-debug.apk`
4. Install to Android via ADB:
   ```bash
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```
